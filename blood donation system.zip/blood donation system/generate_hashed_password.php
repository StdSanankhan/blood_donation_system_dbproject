<?php
// Example: Generating hashed password for an existing password
$plainPassword = "12345";  // Replace this with the password to be hashed
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

echo "Hashed Password: " . $hashedPassword;  // Display the hashed password to use it later
?>
