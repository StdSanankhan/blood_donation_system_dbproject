<?php
session_start();
include 'db.php';  // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get user input
    $username = $_POST['username'];
    $password = $_POST['password'];  // User's plain-text password
    $role = $_POST['role'];  // e.g., 'user' or 'admin'

    // Password Length Validation (see below for this)
    if (strlen($password) < 6) {
        echo "Password must be at least 6 characters long!";
        exit();  // Stop further script execution if the password doesn't meet requirements
    }

    // Hash the password using password_hash() function

    // Debugging: Echo the hashed password to verify it's being created correctly
    echo $hashedPassword;  // Display the hashed password (for debugging purposes)

    // Prepare SQL query to insert user into the database
    $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $role);
    
    // Execute the query
    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Registration failed!";
    }

    // Close the statement
    $stmt->close();
}
?>

<!-- Simple registration form -->
<form method="POST" action="register.php">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="role" placeholder="Role" required> <!-- e.g., 'user' or 'admin' -->
    <button type="submit">Register</button>
</form>
