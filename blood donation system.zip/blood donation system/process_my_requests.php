<?php
session_start();
include('db_connect.php');

// Check if the user is logged in
if (!isset($_SESSION['user_logged_in'])) {
    header("Location: my_requests.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Assuming the user's ID is stored in the session
$blood_requests = [];

// Fetch blood requests for the logged-in user from the database
$sql = "SELECT id, blood_type, status, requested_at FROM blood_requests WHERE recipient_id = '$user_id' ORDER BY requested_at DESC";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $blood_requests[] = $row;
    }
}

// Pass the fetched data to the session for `my_requests.php`
$_SESSION['blood_requests'] = $blood_requests;

// Redirect to `my_requests.php`
header("Location: my_requests.php");
exit();