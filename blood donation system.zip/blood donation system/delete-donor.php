<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if (isset($_GET['id'])) {
    $donor_id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM donors WHERE id = ?");
    $stmt->bind_param("i", $donor_id);
    if ($stmt->execute()) {
        header("Location: donors.php");
        exit();
    } else {
        echo "Error deleting donor.";
    }
}
?>

