<?php
session_start();
include 'db.php';  // Ensure you have a valid database connection

// Handle Signup Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['signup'])) {
    // Get the form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if password and confirm password match
    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if username already exists
        $check_query = "SELECT * FROM users WHERE username = '$username'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $error = "Username already exists!";
        } else {
            // Insert new user into the database
            $insert_query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', 'user')";
            if (mysqli_query($conn, $insert_query)) {
                $success = "Registration successful! You can now log in.";
            } else {
                $error = "Error during registration. Please try again.";
            }
        }
    }
}

// Handle Login Logic
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Get the login data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Query the database to get the user details
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    // Check if the user exists
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);  // Fetch user data

        // Verify the entered password with the stored hashed password
        if (password_verify($password, $user['password'])) {  // Use password_verify for hashed passwords
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Redirect to the dashboard
            header("Location: dashboard.php");
            exit();  // Make sure to exit after the redirect
        } else {
            // Password is incorrect
            $error = "Invalid password!";
        }
    } else {
        // User not found
        $error = "User not found!";
    }
}
?>

<!-- Display the error or success message -->
<?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
<?php if (isset($success)) { echo "<p style='color:green;'>$success</p>"; } ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation Management System</title>
    <link rel="stylesheet" href="login.css">
    <style>
        /* Add styles for hiding the forms */
        .form-container {
            display: none;
        }
        .form-container.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="system-title">
            <h1>Blood Donation Management System</h1>
        </div>

        <!-- Login Form -->
        <div id="login-form" class="form-container active">
            <form action="" method="POST">
                <h2>Login</h2>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" name="login">Login</button>
                <p>Don't have an account? <a href="javascript:void(0);" onclick="toggleForms()">Sign up here</a></p>
            </form>
        </div>

        <!-- Signup Form -->
        <div id="signup-form" class="form-container">
            <form action="" method="POST">
                <h2>Sign Up</h2>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" name="signup">Sign Up</button>
                <p>Already have an account? <a href="javascript:void(0);" onclick="toggleForms()">Login here</a></p>
            </form>
        </div>
    </div>

    <script>
        // Toggle between login and signup forms
        function toggleForms() {
            var loginForm = document.getElementById('login-form');
            var signupForm = document.getElementById('signup-form');

            // Toggle visibility of the forms
            loginForm.classList.toggle('active');
            signupForm.classList.toggle('active');
        }
    </script>
</body>
</html>
