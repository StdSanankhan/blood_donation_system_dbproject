<?php
// Function to check blood compatibility
function is_compatible($requested_blood, $donor_blood) {
    $compatibility = [
        "O-" => ["O-"],
        "O+" => ["O-", "O+"],
        "A-" => ["O-", "A-"],
        "A+" => ["O-", "O+", "A-", "A+"],
        "B-" => ["O-", "B-"],
        "B+" => ["O-", "O+", "B-", "B+"],
        "AB-" => ["O-", "A-", "B-", "AB-"],
        "AB+" => ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"],
    ];

    return isset($compatibility[$requested_blood]) && in_array($donor_blood, $compatibility[$requested_blood]);
}

// Load blood requests from "requests.txt"
if (file_exists('requests.txt')) {
    $blood_requests = file('requests.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
} else {
    $blood_requests = [];
}

// Load donors from "donors.txt"
if (file_exists('donors.txt')) {
    $donors = file('donors.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
} else {
    $donors = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Matching</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: rgb(47, 104, 211);
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        h1 {
            color: rgb(47, 93, 211);
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: rgb(54, 127, 244);
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .no-data {
            text-align: center;
            font-size: 18px;
            color: rgb(47, 72, 211);
        }
    </style>
</head>
<body>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="request_blood.php">Request Blood</a>
        <a href="my_requests.php">My Requests</a>
        <a href="blood_matching.php">Blood Matching</a>
        <a href="logout.php">Logout</a>
    </nav>

    <h1>Blood Matching</h1>

    <?php if (!empty($blood_requests)): ?>
        <table>
            <tr>
                <th>Requester Name</th>
                <th>Requested Blood Type</th>
                <th>Matching Donors</th>
            </tr>

            <?php foreach ($blood_requests as $request): ?>
                <?php
                // Parse the blood request (format: "Name | Blood Type")
                $request_parts = explode(' | ', $request);

                if (count($request_parts) < 2) {
                    continue; // Skip malformed requests
                }

                $requester_name = htmlspecialchars($request_parts[0]);
                $requested_blood_type = htmlspecialchars($request_parts[1]);

                // Find matching donors
                $matching_donors = [];
                foreach ($donors as $donor) {
                    // Parse the donor data (format: "Name | Blood Type | Contact")
                    $donor_parts = explode(' | ', $donor);

                    if (count($donor_parts) < 3) {
                        continue; // Skip malformed donors
                    }

                    $donor_name = htmlspecialchars($donor_parts[0]);
                    $donor_blood_type = htmlspecialchars($donor_parts[1]);
                    $donor_contact = htmlspecialchars($donor_parts[2]);

                    // Check compatibility
                    if (is_compatible($requested_blood_type, $donor_blood_type)) {
                        $matching_donors[] = "$donor_name (Contact: $donor_contact)";
                    }
                }
                ?>
                <tr>
                    <td><?php echo $requester_name; ?></td>
                    <td><?php echo $requested_blood_type; ?></td>
                    <td>
                        <?php
                        if (!empty($matching_donors)) {
                            echo implode("<br>", $matching_donors);
                        } else {
                            echo "No matching donors found.";
                        }
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p class="no-data">No pending blood requests found.</p>
    <?php endif; ?>
</body>
</html>
