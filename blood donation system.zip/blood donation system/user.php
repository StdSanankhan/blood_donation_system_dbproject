<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initialscale=1.0">
 <title>User Dashboard</title>
 <style>
 /* General Reset */
 * {
 margin: 0;
 padding: 0;
 box-sizing: border-box;
 }
 /* Body Styling */
 body {
 font-family: 'Roboto', sans-serif;
 background-color: #f5f5f5;
 display: flex;
 height: 100vh;
 overflow: hidden;
 }
 /* Sidebar */
 nav {
 width: 260px;
 background: linear-gradient(to bottom, #3a5fcd, 
#2a4da1);
 color: white;
 padding: 30px 20px;
 height: 100%;
 position: fixed;
 box-shadow: 4px 0px 10px rgba(0, 0, 0, 0.1);
 }
 nav ul {
 list-style-type: none;
 }
 nav ul li {
 margin: 20px 0;
 }
 nav ul a {
 text-decoration: none;
 color: white;
 font-size: 18px;
 display: block;
 padding: 10px;
 transition: background 0.3s ease;
 }
 nav ul a:hover {
 background-color: #2c3e8c;
 border-radius: 5px;
 }
 /* Main Content Area */
 main {
 margin-left: 260px;
 padding: 20px;
 flex-grow: 1;
 background-color: #fff;
 }
 main h1 {
 font-size: 24px;
 color: #333;
 }
 </style>
</head>
<body>
 <nav>
 <ul>
 <li><a href="user.php">Dashboard</a></li>
 <li><a href="search_donors.php">Search Donors</a></
li>
 <li><a href="request_blood.php">Request Blood</a></
li>
 <li><a href="my_requests.php">My Requests</a></li>
 <li><a href="blood_match.php">Find Matches</a></li> 
<!-- New Link -->
 <li><a href="logout.php">Logout</a></li>
 </ul>
 </nav>
 <main>
 <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
 <p>Use the menu to navigate through the system.</p>
 </main>
</body>
</html>