<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$result = $conn->query("SELECT * FROM donors");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donors List</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Blood Donation Management System</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="add-donor.php">Add Donor</a></li>
            <li><a href="donors.php">Donors</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <header>
            <h2>Donors List</h2>
        </header>

        <table>
            <tr>
                <th>Name</th>
                <th>Blood Type</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
            <?php while ($donor = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $donor['name']; ?></td>
                <td><?php echo $donor['blood_type']; ?></td>
                <td><?php echo $donor['contact_number']; ?></td>
                <td><?php echo $donor['address']; ?></td>
                <td>
                    <a href="edit-donor.php?id=<?php echo $donor['id']; ?>">Edit</a> | 
                    <a href="delete-donor.php?id=<?php echo $donor['id']; ?>">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>