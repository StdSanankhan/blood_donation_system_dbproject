isBloodCompatible
<?php
// Include the file containing the blood compatibility function
include('blood_compatibility.php');

// Example: Recipient and Donor blood types
$recipientBloodType = 'A+';
$donorBloodType = 'O+';

// Check if the blood types are compatible
if (isBloodCompatible($recipientBloodType, $donorBloodType)) {
    echo "The blood types are compatible!";
} else {
    echo "The blood types are not compatible!";
}
?>




<?php
// Function to check blood compatibility
function isBloodCompatible($recipientBloodType, $donorBloodType) {
    $compatibility = [
        'O-' => ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
        'O+' => ['O+', 'A+', 'B+', 'AB+'],
        'A-' => ['A-', 'A+', 'AB-', 'AB+'],
        'A+' => ['A+', 'AB+'],
        'B-' => ['B-', 'B+', 'AB-', 'AB+'],
        'B+' => ['B+', 'AB+'],
        'AB-' => ['AB-', 'AB+'],
        'AB+' => ['AB+']
    ];

    if (in_array($recipientBloodType, $compatibility[$donorBloodType])) {
        return true;  // The blood types are compatible
    }
    return false;  // The blood types are not compatible
}
?>
