<?php
// Start the session (optional if login is not implemented yet)
session_start();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $blood_type = $_POST['blood_type'] ?? '';

    // Validate input
    if (!empty($name) && !empty($blood_type)) {
        // Save the request in a text file (placeholder for database)
        $data = $name . " | " . $blood_type . PHP_EOL;
        file_put_contents('requests.txt', $data, FILE_APPEND);

        // Display success message
        $success = "Blood request submitted successfully!";
    } else {
        // Display error message
        $error = "Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Blood</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        nav {
            background-color: #007bff;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-around;
        }
        nav a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        nav a:hover {
            text-decoration: underline;
        }
        h1 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #ddd;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        form button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
        }
        form button:hover {
            background-color: #0056b3;
            cursor: pointer;
        }
        p {
            text-align: center;
        }
        .message {
            text-align: center;
            font-size: 16px;
            margin: 10px 0;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="request_blood.php">Request Blood</a>
        <a href="my_requests.php">My Requests</a>
        <a href="logout.php">Logout</a>
    </nav>

    <!-- Blood Request Form -->
    <h1>Request Blood</h1>

    <?php if (!empty($success)): ?>
        <p class="message success"><?php echo $success; ?></p>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>

        <label for="blood_type">Blood Type Needed:</label>
        <input type="text" id="blood_type" name="blood_type" placeholder="e.g., A+, O-" required>

        <button type="submit">Request</button>
    </form>
</body>
</html>
