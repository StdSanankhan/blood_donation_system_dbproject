<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['full-name'];
    $email = $_POST['email'];
    $blood_type = $_POST['blood-type'];
    $contact_number = $_POST['contact-number'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("INSERT INTO donors (name, email, blood_type, contact_number, address) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $blood_type, $contact_number, $address);
    if ($stmt->execute()) {
        $success = "Donor added successfully!";
    } else {
        $error = "Error adding donor.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Donor</title>
    <link rel="stylesheet" href="dashboard.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            float: left;
            background: #007bff;
            color: white;
            padding: 15px;
        }
        .sidebar-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
        }
        .sidebar-menu li {
            margin: 10px 0;
        }
        .sidebar-menu a {
            color: white;
            text-decoration: none;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
            background: white;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background: #f9f9f9;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input, 
        .form-container select, 
        .form-container textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        /* Ensuring the button is styled and visible */
        .form-container button {
            background-color: #007bff;
            color: white;
            padding: 12px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%; /* Full width */
            text-align: center;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .error-message, .success-message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
        }
        .error-message {
            color: red;
            background-color: #f8d7da;
        }
        .success-message {
            color: green;
            background-color: #d4edda;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Blood Donation Management System</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="add-donor.php">Add Donor</a></li>
            <li><a href="donors.php">Donors</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <header>
            <h2>Add Donor</h2>
        </header>
        <div class="form-container">
            <form action="" method="POST">
                <label for="full-name">Full Name:</label>
                <input type="text" id="full-name" name="full-name" required placeholder="Enter full name" />

                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required placeholder="Enter email address" />

                <label for="blood-type">Blood Type:</label>
                <select id="blood-type" name="blood-type" required>
                    <option value="">Select blood type</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                </select>

                <label for="contact-number">Contact Number:</label>
                <input type="tel" id="contact-number" name="contact-number" required placeholder="e.g. 123-456-7890" />

                <label for="address">Address:</label>
                <textarea id="address" name="address" rows="4" required placeholder="Enter your address"></textarea>

                <!-- Submit Button placed after the address field -->
                <button type="submit">Submit</button>
            </form>
            <div class="error-message"><?php if (isset($error)) echo $error; ?></div>
            <div class="success-message"><?php if (isset($success)) echo $success; ?></div>
        </div>
    </div>
</body>
</html>
