<?php
// Include the database connection
include("db.php");
session_start();  // Start the session
// Check if user is logged in by verifying session variables
if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to login page
    header("Location: login.php");
    exit();  // Ensure no further code runs after redirect
}
// User is logged in, you can access session data
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Blood Donation System</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Blood Donation</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="donors.php"><i class="fas fa-users"></i> Donors</a></li>
            <li><a href="user.php"><i class="fas fa-user"></i> Recipient</a></li>
            <li><a href="blood_matching.php"><i class="fas fa-useres"></li> Blood Match</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            
        </ul>
    </div>
    <div class="main-content">
        <header>
            <h2>Welcome, <?php echo $username; ?>!</h2>
            <p>You have successfully logged into the Blood Donation System.</p>
        </header>
        
        <div class="dashboard-container">
            <div class="card">
                <h4>Total Users</h4>
                <p>
                    <?php
                    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
                    if ($result) {
                        $data = mysqli_fetch_assoc($result);
                        echo $data['total'];
                    } else {
                        echo "Error fetching data";
                    }
                    ?>
                </p>
            </div>
            <div class="card">
                <h4>Total Donors</h4>
                <p>
                    <?php
                    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM donors");
                    if ($result) {
                        $data = mysqli_fetch_assoc($result);
                        echo $data['total'];
                    } else {
                        echo "Error fetching data";
                    }
                    ?>
                </p>
            </div>
        </div>
        
        <div class="additional-space">
            <div class="box">
                <h4>Upcoming Blood Drives</h4>
                <p>Details about upcoming blood donation events will be listed here.</p>
            </div>
            <div class="box">
                <h4>Recent Contributions</h4>
                <p>Information about recent donor contributions will be shown here.</p>
            </div>
            <div class="box">
                <h4>Volunteer Opportunities</h4>
                <p>Volunteer roles and opportunities to support the cause will be displayed here.</p>
            </div>
        </div>
    </div>
</body>
</html>
