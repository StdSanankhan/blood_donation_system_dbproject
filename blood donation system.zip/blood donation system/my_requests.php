<?php
// Start the session (optional if you don't want login logic)
session_start();

// Retrieve all blood requests from a placeholder file (or database)
$blood_requests = file_exists('requests.txt') ? file('requests.txt', FILE_IGNORE_NEW_LINES) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Requests</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5faff; /* Light blue background */
            margin: 0;
            padding: 0;
            color: #333; /* Dark text for readability */
        }

        /* Navigation Bar */
        nav {
            background-color: #007bff; /* Blue background */
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        /* Page Header */
        h1 {
            color: #0056b3; /* Dark blue for headers */
            text-align: center;
            margin-top: 20px;
        }

        /* List of Requests */
        ul {
            list-style: none;
            padding: 0;
            width: 80%;
            margin: 20px auto;
            background-color: white; /* White background for contrast */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        ul li {
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
        }

        ul li:last-child {
            border-bottom: none;
        }

        ul li:hover {
            background-color: #e3f2fd; /* Light blue hover effect */
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            color: #0056b3;
            font-size: 18px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="request_blood.php">Request Blood</a>
        <a href="my_requests.php">My Requests</a>
        <a href="logout.php">Logout</a>
    </nav>

    <!-- My Requests -->
    <h1>My Blood Requests</h1>
    <ul>
        <?php if (!empty($blood_requests)): ?>
            <?php foreach ($blood_requests as $request): ?>
                <li><?php echo htmlspecialchars($request); ?></li>
            <?php endforeach; ?>
        <?php else: ?>
            <li class="no-data">No requests found.</li>
        <?php endif; ?>
    </ul>
</body>
</html>
