<?php
// Include the database connection
include("connection.php");

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the donor's ID from the form (hidden field)
    $donor_id = $_POST['id'];  
    $name = $_POST['name'];     // Donor's name
    $email = $_POST['email'];   // Donor's email
    $blood_type = $_POST['blood_type'];  // Donor's blood type
    $contact_number = $_POST['contact_number'];  // Donor's contact number
    $address = $_POST['address'];  // Donor's address
    
    // Prepare the SQL query to update the donor info based on their ID
    $query = "UPDATE donors 
              SET name = ?, email = ?, blood_type = ?, contact_number = ?, address = ?
              WHERE id = ?";  // Update the donor record where ID matches

    // Prepare the SQL statement
    $stmt = $conn->prepare($query);

    // Bind the form data to the query (use appropriate types)
    $stmt->bind_param("sssssi", $name, $email, $blood_type, $contact_number, $address, $donor_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Success message
        echo "Donor information updated successfully!";
        // Redirect to another page (e.g., donor list page)
        header("Location: donors_list.php");  // Change this to your donor list page
        exit();
    } else {
        // Error message if update fails
        echo "Error updating donor information!";
    }

    // Close the statement
    $stmt->close();
}
?>
