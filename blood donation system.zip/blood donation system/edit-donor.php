<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Fetch donor details
if (isset($_GET['id'])) {
    $donor_id = intval($_GET['id']);
    $query = "SELECT * FROM donors WHERE id = $donor_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $donor = mysqli_fetch_assoc($result);
    } else {
        echo "Donor not found.";
        exit();
    }
} else {
    header("Location: donors.php");
    exit();
}

// Update donor details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $blood_type = mysqli_real_escape_string($conn, $_POST['blood_type']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    $update_query = "UPDATE donors SET name = '$name', blood_type = '$blood_type', contact_number = '$contact_number', address = '$address' WHERE id = $donor_id";
    if (mysqli_query($conn, $update_query)) {
        header("Location: donors.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Donor</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Blood Donation Management System</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="add-donor.php">Add Donor</a></li>
            <li><a href="donors.php">Donors</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <header>
            <h2>Edit Donor</h2>
        </header>

        <form action="" method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($donor['name']); ?>" required>

            <label for="blood_type">Blood Type:</label>
            <input type="text" id="blood_type" name="blood_type" value="<?php echo htmlspecialchars($donor['blood_type']); ?>" required>

            <label for="contact_number">Contact Number:</label>
            <input type="text" id="contact_number" name="contact_number" value="<?php echo htmlspecialchars($donor['contact_number']); ?>" required>

            <label for="address">Address:</label>
            <textarea id="address" name="address" required><?php echo htmlspecialchars($donor['address']); ?></textarea>

            <button type="submit">Update Donor</button>
        </form>
    </div>
</body>
</html>
