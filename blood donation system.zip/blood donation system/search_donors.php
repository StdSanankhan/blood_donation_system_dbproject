<?php
session_start();
include('db_connect.php');

// Check if blood group is set in session
if (!isset($_SESSION['requested_blood_group'])) {
    header("Location: recipient_request.php");
    exit();
}

$requested_blood_group = $_SESSION['requested_blood_group'];

// Fetch donors
$sql = "SELECT * FROM donors";
$result = mysqli_query($conn, $sql);
$donors = [];
while ($row = mysqli_fetch_assoc($result)) {
    $donors[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Donors</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .donor {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            color: #fff;
        }
        .matching {
            background-color: #28a745; /* Green */
        }
        .non-matching {
            background-color: #dc3545; /* Red */
        }
    </style>
</head>
<body>
    <h1>Search Donors</h1>
    <h2>Requested Blood Group: <?php echo htmlspecialchars($requested_blood_group); ?></h2>
    <ul>
        <?php foreach ($donors as $donor): ?>
            <li class="donor <?php echo ($donor['blood_type'] === $requested_blood_group) ? 'matching' : 'non-matching'; ?>">
                <strong><?php echo htmlspecialchars($donor['name']); ?></strong><br>
                Blood Group: <?php echo htmlspecialchars($donor['blood_type']); ?><br>
                Location: <?php echo htmlspecialchars($donor['location']); ?><br>
                Contact: <?php echo htmlspecialchars($donor['contact']); ?><br>
                Status: <?php echo ($donor['availability'] === 'Yes') ? 'Available' : 'Not Available'; ?>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
