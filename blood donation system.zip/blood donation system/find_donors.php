<?php
// Include database connection
include("db_connect.php");

// Query to get all recipients who have a 'Pending' status
$query = "SELECT * FROM recipients WHERE status = 'Pending'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($recipient = $result->fetch_assoc()) {
        echo "<h3>Recipient: " . htmlspecialchars($recipient['name']) . "</h3>";
        echo "<p>Blood Type: " . htmlspecialchars($recipient['blood_type']) . "</p>";
        echo "<p>Contact: " . htmlspecialchars($recipient['contact_number']) . "</p>";
        echo "<p>Email: " . htmlspecialchars($recipient['email']) . "</p>";

        // Query to find compatible donors
        $donor_query = "SELECT * FROM donors WHERE blood_type = ? AND availability = 'Yes'";
        $stmt = $conn->prepare($donor_query);
        $stmt->bind_param("s", $recipient['blood_type']);
        $stmt->execute();
        $donor_result = $stmt->get_result();

        echo "<h4>Matching Donors:</h4>";

        if ($donor_result->num_rows > 0) {
            echo "<ul>";
            while ($donor = $donor_result->fetch_assoc()) {
                echo "<li>" . htmlspecialchars($donor['name']) . " - Blood Type: " . htmlspecialchars($donor['blood_type']) . " - Location: " . htmlspecialchars($donor['location']) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>No donors found for this blood type.</p>";
        }

        // Update the recipient status to 'Fulfilled' if a match is found
        if ($donor_result->num_rows > 0) {
            $update_query = "UPDATE recipients SET status = 'Fulfilled' WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("i", $recipient['id']);
            $stmt->execute();
            echo "<p>Status updated to 'Fulfilled'.</p>";
        }
    }
} else {
    echo "<p>No pending recipient requests.</p>";
}
?>