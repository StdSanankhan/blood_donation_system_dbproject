<!-- nav.php -->
<nav>
    <ul>
        <li><a href="user.php">Dashboard</a></li>
        <li><a href="request_blood.php">Request Blood</a></li>
        <li><a href="my_requests.php">My Requests</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>
